import {StatusPluginCtrl} from './status_ctrl';

export {
  StatusPluginCtrl as PanelCtrl
};
